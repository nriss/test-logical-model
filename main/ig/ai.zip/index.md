# Accueil - Test - Héritage de Modèles Logiques v0.1.0

* [**Table of Contents**](toc.md)
* **Accueil**

## Accueil

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/fhir/test-logical-model/ImplementationGuide/ans.fhir.fr.test-logical-model | *Version*:0.1.0 |
| Draft as of 2026-03-27 | *Computable Name*:TestLogicalModel |

### Introduction

Cet IG est un **bac à sable technique** destiné à tester l'héritage de modèles logiques FHIR.

L'objectif est de vérifier qu'il est possible d'étendre un modèle logique existant (ici [`EHDSPatient`](https://www.xt-ehr.eu/fhir/models/StructureDefinition-EHDSPatient.html) du projet Xt-EHR) en y ajoutant des champs spécifiques au contexte français.

### Ce qui est testé

| | | |
| :--- | :--- | :--- |
| [`EHDSPatient`](https://www.xt-ehr.eu/fhir/models/StructureDefinition-EHDSPatient.html)(Xt-EHR) | [`ANSPatient`](StructureDefinition-ANSPatient.md) | INS-NIR, INS-NIA, lieu de naissance, nationalité, situation familiale |

### Dépendances




